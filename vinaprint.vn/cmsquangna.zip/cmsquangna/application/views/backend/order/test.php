<div class="row">
    <div class="panel-action">
        <div class="row">
            <div class="col-md-4 col-md-offset-2">
                <div class="left-action text-left clearfix">
                    <div class="row">
                        <h4 class="col-md-4">Đơn hàng</h4>
                        <div class="ck-group col-md-8">
                            <label for="Tất cả"><input type="checkbox" name="1" checked value=""/ > <span>Tất cả</span></label>
                            <label for="Tất cả"><input type="checkbox" name="1" checked value=""/ > <span>POS</span></label>
                            <label for="Tất cả"><input type="checkbox" name="1" checked value=""/ > <span>Đặt hàng</span></label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="right-action text-right">
                    <div class="btn-groups">
                        <button type="button" class="btn btn-warning" name=""><i class="fa fa-floppy-o"></i> Lưu</button>
                        <button type="button" class="btn btn-primary" name=""><i class="fa fa-shopping-cart"></i> Đặt hàng</button>
                        <button type="button" class="btn btn-primary" name=""><i class="fa fa-desktop"></i> Bán hàng</button>
                        <button type="button" class="btn btn-success" name=""><i class="fa fa-download"></i> Xuất Excel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end .panel-action -->