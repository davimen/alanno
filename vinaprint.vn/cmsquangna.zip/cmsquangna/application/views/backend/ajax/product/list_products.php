<table class="table table-bordered table-striped">
    <thead>
    <tr>
        <th class="text-center"><label class="checkbox" style="margin: 0;"><input type="checkbox"  class="checkbox chkAll"><span style="width: 15px; height: 15px;"></span></label></th>
        <th class="text-center">Tên Hàng hóa</th>
        <th class="text-center">Mã hàng hóa</th>
        <th class="text-center">SL</th>
        <th class="text-center" style="background-color: #fff;">Giá bán</th>
        <th class="text-center">Nhóm hàng</th>
        <th class="text-center">Chủng loại</th>
        <th class="text-center">Hình</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
    <?php if ( isset( $data[ '_list_product' ] ) && count( $data[ '_list_product' ] ) ) :
        foreach ( $data[ '_list_product' ] as $key => $item ) : ?>
            <tr>
                <td class="text-center"><label class="checkbox" style="margin: 0;"><input type="checkbox"
                                                                                          value="<?php echo $item[ 'ID' ]; ?>"
                                                                                          class="checkbox chk"><span style="width: 15px; height: 15px;"></span></label>
                </td>
                <td class="text-left prd_name_copy-<?php echo $item['ID']; ?>" onclick="cms_edit_product(<?php echo $item['ID']; ?>)" style="color: #2a6496; cursor: pointer; width: 500px;"><?php echo $item[ 'prd_name' ]; ?></td>
                <td class="text-center">SP000<?php echo $item[ 'ID' ]; ?></td>
                <td class="text-center"><?php echo $item[ 'prd_sls' ]; ?></td>
                <td class="text-right" style="font-weight: bold;"><?php echo number_format( $item[ 'prd_sell_price' ] ); ?></td>
                <td><?php echo cms_getNamegroupbyID( $item[ 'prd_group_id' ] ); ?></td>
                <td><?php echo cms_getNamecategorybyID( $item[ 'prd_category_id' ] ); ?></td>
                <td class="text-center" style="width: 35px;"><?php echo ( !empty($item['prd_image_url'])) ? "<img src='{$item['prd_image_url']}' alt='{$item['prd_name']}' width='22' height='22' style='border-radius: 15px; padding: 3px; border: 1px solid #ccc;'/>" : '<i class="fa fa-cloud-upload" style="font-size: 18px; color: #337ab7; cursor: pointer; "></i>'?></td>
                <td class="text-center"><i title="Copy" onclick="cms_copy_product(<?php echo $item['ID']; ?>);" class="fa fa-files-o blue" style="margin-right: 5px;"></i> <i title="Ngừng kinh doanh" class="fa fa-pause" onclick="cms_change_status(<?php echo $item['ID']; ?>);"
                                                                                                    style="margin-right: 5px; color: #C6699F; cursor: pointer;"></i>
                    <i class="fa fa-trash-o" style="color: darkred;" title="Xóa" onclick="cms_del_temp_product(<?php echo $item['ID']; ?>)"></i></td>
            </tr>
        <?php endforeach;
    else :
        echo '<tr><td colspan="9" class="text-center">Không có dữ liệu</td></tr>';
    endif;

    ?>

    </tbody>
</table>
<div class="alert alert-info summany-info clearfix" role="alert">
    <div class="sm-info pull-left padd-0">SL hàng hóa/SL chủng loại: <span><?php echo (isset($data['_sl_product'])) ? $data['_sl_product']: 0; ?>/<?php echo (isset($data['_sl_category'])) ? $data['_sl_category']: 0; ?></span></div>
    <div class="pull-right ajax-pagination">
        <?php echo $_pagination_link; ?>
    </div>
</div>
