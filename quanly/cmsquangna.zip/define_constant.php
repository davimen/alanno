<?php
/************ Database ************/

define( 'CMS_DB_HOST', 'localhost' );
define( 'CMS_DB_USER', 'root' );
define( 'CMS_DB_PASSWORD', '' );
define( 'CMS_DB_NAME', 'cms_quangna' );
define( 'CMS_DB_PREFIX', 'cms_' );

/************ End Database ************/

/************ ORTHER ************/
define( 'CMS_BASE_URL', 'http://localhost/cmsquangna/' );
define( 'CMS_DEFAULT_LANGUAGE', 'vietnamese' );
define( 'CMS_PREFIX', md5('CMS_') );
define( 'COOKIE_EXPIRY', 60480 );